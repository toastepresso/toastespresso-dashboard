# capability-matrix.md: how each tool connects

You are the AI running this build. **The owner's stack is already confirmed** (it
is named in `CLAUDE.md` and throughout this kit) — do **not** re-ask the owner
which tools they use. Use this file at **Step 0 (triage)** of the per-source
connection pattern in `playbook.md`: look up the owner's confirmed tool here BEFORE
creating any account or credential, for the path, plan requirements and fallback.
The other tools listed below are detail for the confirmed ones plus the **"Other"**
fallback — not a menu to choose from.

Two standing rules:

1. **This matrix was verified against provider documentation in June 2026.
   Providers change.** Treat every entry as the starting point and re-verify
   against the tool's current docs before wiring anything. If reality
   disagrees with this file, reality wins.
2. **Read-only, minimum scope, always.** Whatever the tool offers, request the
   least access that feeds the metrics in `kpi-spec.md`. This build never
   writes to the owner's systems.

How to read each entry:

- **Variant check** — confirm WHICH product the owner actually runs, in
  business terms, before connecting. Several brands sell two different
  products under one name.
- **Usable API / plan gate** — whether the owner can realistically get API
  access themselves, and any subscription tier it depends on.
- **Auth** — OAuth (owner clicks Allow, tokens refresh) vs a pasted key/token
  (owner copies a credential once). Either way credentials go to Worker
  secrets only.
- **Sandbox risk** — whether a test/demo environment exists that could feed
  fake data; how to spot it.
- **Fallback** — the next rung on the ladder if the API path is closed
  (see `playbook.md`, "The fallback ladder").
- **Extras** — optional metrics this tool could add beyond the core six
  (offer only what its API really exposes; `kpi-spec.md` honesty rules apply).

---

## POS systems

The POS supplies **one core number: the count of completed transactions**
(voids and refunds excluded). Never pull a dollar figure from it.

### Square

- **Variant check:** "Square" covers Square POS and Square for Restaurants.
  Both sit on the same developer platform and APIs, so the connection path is
  identical; just confirm with the owner which they use so reporting language
  matches what they see in their app.
- **Usable API:** yes, on all plans, for the owner's own account.
- **Auth (own-account, recommended):** the owner creates a free application in
  the **Square Developer Console** (developer.squareup.com); the app provides
  a **production personal access token**. Square documents personal access
  tokens as suitable for production use in custom own-account integrations —
  no OAuth flow needed. Note: a personal access token is **full-access** (it
  cannot be scope-trimmed). The build never writes; mitigate by storing it
  only in Worker secrets and telling the owner not to share it.
- **Transaction count:** count completed orders/payments for the period
  (Orders search, or Payments list) excluding voided/cancelled. Refunds are
  separate records — do not let them reduce the count. Verify exact
  query/state fields against current docs at build time.
- **Sandbox risk:** **high-signal and real.** The Developer Console has a
  Sandbox/Production toggle; sandbox and production have separate tokens and
  separate API base URLs (`connect.squareupsandbox.com` vs
  `connect.squareup.com`). If the data looks fake, near-empty, or the token
  only works against the sandbox host, the owner copied the sandbox token —
  switch the Console toggle to Production and copy that token instead.
- **Fallback:** rarely needed. Square's own scheduled report exports → guided
  upload.
- **Extras:** sales by category, item, and daypart; per-staff attribution
  (team member on the order/payment). Offer after the core board is verified.

### Lightspeed

- **Variant check — critical, two different products:**
  - **Lightspeed Retail (X-Series)** — shops; formerly Vend.
  - **Lightspeed Restaurant (K-Series)** — hospitality venues.
  Ask the owner in business terms: "is your Lightspeed for running a shop, or
  for tables/orders in a restaurant or bar?" Do not connect anything until
  this is settled — the two have entirely different APIs and access models.
- **Lightspeed Retail (X-Series):** usable API, yes. Accounts created after
  January 2026 use **private apps** (created in the account's developer/
  personal-token settings by an admin) — personal tokens are the legacy
  equivalent on older accounts. Token-style auth, pasted once. Read access to
  sales suffices for the transaction count.
- **Lightspeed Restaurant (K-Series):** API access is **reserved for partners
  and approved merchants** — the owner must request it through their
  Lightspeed account manager. Treat as gated: ask the owner to request access
  (it may take days), and in the meantime run the **fallback ladder** so the
  build keeps moving; revisit the live API when access lands.
- **Sandbox risk:** low for X-Series (no separate demo environment in normal
  owner flow); confirm at build.
- **Fallback:** the product's scheduled sales-report export, auto-ingested →
  guided upload.
- **Extras (X-Series):** sales by product/category.

### Toast

- **Variant check:** one product; US-centric.
- **Usable API / plan gate:** yes via **standard API access** — read-only API
  credentials owners can request — but it is **plan-gated**: the location
  needs an active **Toast Restaurant Management Suite Essentials (or higher)**
  subscription, and the requesting login needs the **Manage Integrations**
  permission. If the owner is on a lower tier, the live-API rung is closed.
- **Auth:** API credentials issued through Toast's access process (standard
  API access), pasted to Worker secrets. Verify the current request flow in
  Toast's developer guide at build time.
- **Sandbox risk:** Toast maintains separate environments for partners;
  standard access is tied to the owner's live location — low risk, still
  confirm real data on first sync.
- **Fallback (common path on lower tiers):** Toast's scheduled report exports
  → guided upload.
- **Extras:** menu/item sales breakdowns where the credentials expose them.

### Any other POS (the "Other" path)

Run the **generic triage** at the bottom of this file, then Appendix D of the
playbook. The transaction count is the only number you need from it — that
keeps even a thin API (or an export) viable.

---

## Accounting systems

The accounting software supplies **every money figure, always excluding
GST/sales tax**: Revenue, Cost of goods, Wage %, Overheads. It is also the
source of truth the reconciliation pass checks against.

### Xero

- **Variant check:** one product. If the owner's adviser manages multiple
  organisations, the **right organisation** matters more than the product —
  confirm the org name on connection.
- **Usable API:** yes. The owner (or you, driving their logged-in browser
  steps) creates a free app at **developer.xero.com → My Apps**. The free
  **Starter** tier (up to 5 connections, 1,000 calls/org/day, 60/min) is
  ample for one venue's dashboard.
- **Auth:** OAuth 2.0 authorization-code. **Apps created on or after 2 March
  2026 must use granular scopes** — the old broad `accounting.reports.read`
  is not available to new apps. Request exactly:
  - `offline_access` (refresh token)
  - `accounting.reports.profitandloss.read` (the P&L — the only report the
    core six need)
  Optionally `accounting.settings.read` if account-level diagnosis during
  reconciliation needs the chart of accounts list.
  **Token behaviour that bites:** Xero refresh tokens are single-use and
  rotate on every refresh (and expire after ~60 days idle) — the scaffold's
  token store already persists the new refresh token on every refresh; do not
  bypass it.
  **Avoid the Journals endpoint** (`/Journals`) — it is premium-gated on
  Xero's paid API tiers. The P&L report endpoint is all this build needs.
- **Verified specifics (June 2026 — stated with a date so the next build does not
  re-derive them):**
  - Authorize URL: `https://login.xero.com/identity/connect/authorize`
  - Token URL: `https://identity.xero.com/connect/token` — **HTTP Basic client
    auth** (`client_secret_basic`): send `Authorization: Basic
    base64(client_id:client_secret)`, NOT the secret in the form body. The
    scaffold's per-adapter `tokenAuth: 'basic'` flag does exactly this — set it on
    the accounting adapter. Posting the secret in the body fails the exchange
    *after* the owner clicks Allow (a silent, wasted re-auth), so this is not
    optional.
  - P&L: `GET https://api.xero.com/api.xro/2.0/Reports/ProfitAndLoss` with the
    `Xero-Tenant-Id` header and `Accept: application/json` (it returns XML
    otherwise). The `periods` parameter is **capped at 12** — for a 24-month
    trend make two ≤12-period calls (or month-by-month) and stitch them.
  - **Xero's doc pages are client-rendered**, so a plain fetch returns an empty
    shell — don't burn calls trying. The machine-readable source of truth is the
    **XeroAPI OpenAPI repo on GitHub** (cloneable; `github.com` works in the
    sandbox even when `api.github.com` is blocked). One caveat: that spec still
    lists the *old broad* `accounting.reports.read` against the P&L endpoint —
    that scope is **gone for apps created on/after 2 Mar 2026**; the granular
    `accounting.reports.profitandloss.read` above is correct. The spec is stale on
    this point; don't waver.
- **Reading the P&L + finding wages/super (the single most reconciliation-fragile
  step — this is where a build misses "to the cent"):** the report JSON is
  `Reports[0].Rows[]`. Each Row has a `RowType`: `Header`, `Section` (carries a
  `Title` like "Income", "Cost of Sales", "Operating Expenses" and nested `Rows`),
  or `SummaryRow`. Cells are in `Cells[]` — `Cells[0].Value` is the line label and
  the later cells are period amounts (one extra amount column per period in a
  multi-period report; map columns to your requested months in order).
  - **Revenue** = the Income/Revenue section total (trading income only — exclude
    any "Other Income" section). **Cost of goods** = the Cost of Sales section
    total. **Overheads** = the Operating Expenses total **minus** the wage/super
    lines.
  - **Wage/super detection:** within Operating Expenses, match line labels
    case-insensitively against
    `wages|salaries|superannuation|super|payroll|annual leave|long service|workcover`,
    then **confirm the exact account names with the owner at reconciliation**:
    "I've counted these as wages and super: <list>. Is that all of them, and
    nothing extra?" Keyword match *proposes*; the owner *confirms*. This catches
    both over-matches (e.g. "Employee amenities" or "Staff training" must NOT be
    counted) and a non-standard wage account the keywords miss — and it's a
    legitimate business question, not a technical one. It is what makes Wage % and
    Overheads reconcile exactly.
  - Representative shape (single period; a multi-period report repeats the amount
    cell once per period):
    ```json
    { "Reports": [ { "ReportName": "Profit and Loss", "Rows": [
      { "RowType": "Section", "Title": "Income", "Rows": [
        { "RowType": "Row", "Cells": [ {"Value":"Sales"}, {"Value":"152340.00"} ] },
        { "RowType": "SummaryRow", "Cells": [ {"Value":"Total Income"}, {"Value":"152340.00"} ] } ] },
      { "RowType": "Section", "Title": "Cost of Sales", "Rows": [
        { "RowType": "Row", "Cells": [ {"Value":"Purchases"}, {"Value":"41880.00"} ] },
        { "RowType": "SummaryRow", "Cells": [ {"Value":"Total Cost of Sales"}, {"Value":"41880.00"} ] } ] },
      { "RowType": "Section", "Title": "Operating Expenses", "Rows": [
        { "RowType": "Row", "Cells": [ {"Value":"Wages and Salaries"}, {"Value":"47020.00"} ] },
        { "RowType": "Row", "Cells": [ {"Value":"Superannuation"}, {"Value":"5172.00"} ] },
        { "RowType": "Row", "Cells": [ {"Value":"Rent"}, {"Value":"9800.00"} ] },
        { "RowType": "SummaryRow", "Cells": [ {"Value":"Total Operating Expenses"}, {"Value":"61992.00"} ] } ] }
    ] } ] }
    ```
    Here Revenue = 152,340; COGS = 41,880; wages+super = 47,020 + 5,172 = 52,192
    (Wage %); Overheads = 61,992 − 52,192 = 9,800. **Reuse this section-walk +
    keyword + owner-confirm pattern for MYOB and QuickBooks** — same P&L shape,
    different JSON field names.
- **Org confirm:** after connecting, read the connections list (tenant name)
  and have the owner confirm it is their business — not a personal org, not
  the bookkeeper's other client.
- **Sandbox risk:** the **Demo Company** — a practice org full of fake data.
  If the tenant name contains "Demo Company", flag it and reconnect to the
  real organisation.
- **Fallback:** rarely needed (the API path is open on every Xero plan).
  Scheduled P&L export → guided upload.
- **Extras:** none needed — the P&L feeds everything.

### MYOB

- **Variant check:** "MYOB Business" (browser; covers the former Essentials
  and AccountRight browser products) vs desktop-era AccountRight files.
  Confirm the owner works in the browser product; older desktop company files
  may need different handling — verify at build.
- **Usable API:** yes. Register an app via the **my.myob Developer Tab** to
  get OAuth credentials.
- **Auth:** OAuth 2.0 with **granular scopes** (post-March-2025 scheme; the
  old `CompanyFile` scope is dead). Request the least read scope set that
  exposes the P&L/report data. Redirect URIs must be **https**. **Only an
  administrator user of the company file can approve the connection** — the
  owner needs their admin login, not a staff one (the playbook's prep step
  already demands admin logins).
- **Sandbox risk:** low; no widely-used demo org in the owner flow. Confirm
  real figures on first sync.
- **Fallback:** scheduled P&L export → guided upload.

### QuickBooks Online

- **Variant check:** QuickBooks **Online** vs QuickBooks Desktop. This path
  is for Online; Desktop has no equivalent owner-friendly route — if the
  owner runs Desktop, go straight to the fallback ladder.
- **Usable API:** yes. The owner creates a free developer account and app at
  **developer.intuit.com**; the app provides OAuth client credentials.
- **Auth:** OAuth 2.0, scope `com.intuit.quickbooks.accounting`. The P&L
  comes from the reports endpoints. Verify the current minor-version and
  report parameters at build time.
- **Sandbox risk:** **real.** Intuit developer accounts come with sandbox
  companies full of sample data, and the app has separate
  development/production keys. If the connected company looks like "Sandbox
  Company_US_1" or the data is sample-ish, the wrong environment is wired —
  use production keys and connect the owner's real company.
- **Fallback:** scheduled P&L export → guided upload.

### Any other accounting tool

Generic triage below + Appendix D. Remember: if the accounting tool truly has
no machine path, rung 3 (a scheduled P&L export the owner downloads and drops
on the dashboard's upload screen) still delivers every money metric —
slower, but correct.

---

## Rostering / timesheets

Optional source. It adds exactly one thing to the core board: the **projected
Wage %** (rostered cost ÷ revenue), always labelled *projected*. The actual
Wage % already comes from the accounting software — **if rostering is gated
or missing, nothing on the core board is lost.**

### Deputy

- **Variant check:** one product.
- **Usable API:** yes, from inside the owner's own Deputy install.
- **Auth (simplest, recommended):** a **permanent token** created from the
  install's OAuth-clients screen:
  `https://{install}.{geo}.deputy.com/exec/devapp/oauth_clients` — add a
  client, then "Get an Access Token". **The token is shown once, in a modal,
  and never again** — have the owner paste it to you immediately; it goes
  straight to Worker secrets. (Full OAuth 2.0 also exists — 24-hour access
  tokens with rotating refresh — but the permanent token avoids the refresh
  dance entirely for an own-account build.)
- **Permission note:** the token carries the creating user's permission level
  — it must be created while logged in as the owner/admin.
- **Data:** rosters and timesheets via Deputy's resource API. How rostered
  *cost* is exposed (cost fields vs hours × pay rates) varies — verify the
  current shape at build time and compute accordingly.
- **Sandbox risk:** low; installs are live by nature. Confirm on first sync.
- **Fallback:** Deputy's scheduled exports → labour from the accounting
  software (the actual Wage % — already wired) → skip projected.

### Tanda (Workforce.com)

- **Variant check:** Tanda rebranded around Workforce.com in some markets —
  same platform family; the AU product remains Tanda. Confirm which the owner
  logs into.
- **Usable API:** yes. The owner (logged in as admin) creates a **personal
  access token** in-product (`my.tanda.co → API → access tokens`). Shown
  once; valid until revoked; Bearer-header auth. Choose the least scopes
  offered at creation.
- **Sandbox risk:** low.
- **Fallback:** as Deputy.

### Urhere

- **Variant check:** one product (AU rostering).
- **Usable API:** **no public developer API found as of June 2026.** Do not
  promise a live connection. Check current docs once at build time in case
  this has changed, then move on.
- **The good news (use this):** Urhere ships a built-in **Xero timesheet
  export**. Labour lands in the accounting software, which is already
  connected — so the actual Wage % is fully covered (ladder rung: same number
  from another tool). The only thing not available is the *projected* Wage %;
  the card shows "not configured" for projected, exactly as `kpi-spec.md`
  prescribes.
- **Fallback ladder:** Xero timesheet export (above) → skip projected Wage %.
  Never block the build on this tool.

### No rostering tool

Nothing to connect. Actual Wage % comes from the accounting software;
projected Wage % shows "not configured". This is a complete, honest setup.

### Any other rostering tool

Generic triage below + Appendix D. If it exports timesheets to the
accounting software (many do), that export is usually the fastest honest rung.

---

## Getting data without an API (the concrete rungs)

APIs are the preferred path, never the only one. The dashboard's scaffold
ships the plumbing for every rung below; your job is picking the
least-fragile one available and wiring it. The owner never hears "it can't
be done" - they hear which rung you picked and what arrives when.

**Rung 1 - the tool's own report scheduler, emailed out (automate this
first).** Most hospitality tools - including ones with gated APIs - can email
a sales/labour report on a daily or weekly schedule (look in-product for
"scheduled reports", "email reports", "subscriptions", or ask the tool's
support to switch it on). Once the report is flowing, three ways to catch it,
in order of preference:

1. **Owner's domain on their Cloudflare → Email Routing → the dashboard
   Worker.** If the owner has a domain (their venue website) and its DNS can
   live in their Cloudflare account, create an address like
   `data@theirvenue.com`, route it to the Worker, and complete the Worker's
   `email()` handler (parse with postal-mime, find the attachment, reuse the
   same parse-and-save path as `/api/ingest`). Fully automatic, no extra
   accounts.
2. **An inbound-mail bridge.** If their domain can't move, a small
   inbound-email service (e.g. CloudMailin or Mailgun inbound routes) can
   receive the report address and POST the content to the Worker's
   `/api/ingest` endpoint with the `INGEST_TOKEN`. One extra free-tier
   account; still fully automatic.
3. **The 30-second drop.** The report lands in the owner's own inbox; they
   open the dashboard's Connections screen and drop the file on the upload
   panel. Not automatic, but honest and reliable - agree the cadence with the
   owner and the dashboard shows freshness either way.

**Rung 2 - scheduled pull of the tool's own export.** Some tools expose a
stable, authenticated export/download URL (a saved report link, a back-office
"download CSV" endpoint). Wire the adapter's `scheduledPull()` and uncomment
the cron in `wrangler.toml` so the Worker fetches it on a schedule. Use only
where the URL is stable and uses a proper token or basic auth. **Do not**
build fragile browser automation against a tool's login screen, and never
store the owner's interactive password for scraping - that path breaks
silently and teaches the owner to distrust the board.

**Rung 3 - the same number from a tool that already has it.** Often the
cleanest: many POS systems post daily summaries into the accounting software,
and most rostering tools export timesheets to payroll/accounting. If the
number already lands in a connected source, read it there and skip the
integration entirely (this is how labour works when rostering is gated -
actual Wage % comes from accounting regardless).

**Rung 4 - guided upload as the floor.** The upload panel + `INGEST_TOKEN`
(the owner's "upload code") always works: owner downloads the usual report,
drops it on the Connections screen, under a minute. Agree a rhythm (e.g.
Monday morning), and the dashboard's last-synced line keeps everyone honest
about freshness.

**Rules that hold on every rung:** ingested data is still reconciled per
`playbook.md` (to the cent for money, count against the POS screen); the
dashboard states when data last arrived; re-uploading a corrected file for
the same dates is safe (same-day rows overwrite); and if a rung needs
something only the vendor can switch on, ask the owner to request it and keep
building on a lower rung meanwhile - never stall the build waiting.

If none of the named rungs fit a strange tool, inventing a safe variant is
your job. Work out where the data already flows (inbox, accountant, another
tool, a nightly file), catch it at the easiest point, and feed it to
`/api/ingest`.

---

## Generic triage (any unlisted tool, every "Other")

Work through these questions against the tool's **current** documentation —
never from memory:

1. **Exact product and plan.** In the owner's words: what is it called on
   their invoice/login screen? Brands hide multiple products behind one name.
2. **Does a self-serve API exist for an owner?** Look for a developer portal,
   an in-product "API"/"integrations"/"developer" settings screen, or
   documented personal tokens. Partner-only programs (apply-and-wait) count
   as **gated** — start the fallback ladder in parallel if so.
3. **Auth family.** Personal/permanent token pasted once, or OAuth
   (client id + secret + redirect URL + Allow screen)? The scaffold supports
   both; OAuth needs the scaffold's callback URL registered exactly.
4. **Least read-only scope** that yields the one number this source owes the
   board (count for POS, P&L lines for accounting, rostered cost for
   rostering).
5. **Sandbox/live split?** If the platform has demo data, test companies, or
   a sandbox toggle, plan the "confirm real data" check before trusting the
   first sync.
6. **No usable path?** Say so plainly to yourself and take the fallback
   ladder (`playbook.md`): the tool's own scheduled export, auto-ingested →
   the same number from an already-connected tool → guided upload. Never tell
   the owner it can't be done; pick the next rung.

When you've answered all six, run the per-source connection pattern in
`playbook.md`.
