# playbook.md: the build, step by step

You are the AI running this build. `CLAUDE.md` is the contract; this file is
the route. Follow the milestones in order. This playbook is written for you,
so it may contain technical detail; **nothing technical in here is ever shown
to the owner**. Everything you put in front of the owner is a plain action or
an observation, in their language.

A few standing instructions before you start:
- This kit was assembled July 2026. Providers change their connection
  steps. Before wiring any tool, check its current documentation; the
  capability matrix and the appendices are your starting point, not gospel.
- At every milestone, announce where you are ("Milestone 3 of 6") and what
  the owner will see at the end of it.
- **After writing or editing ANY scaffold file, run `node selftest.mjs` in the
  scaffold folder and push only when it is green.** Writes can silently truncate a
  file; a truncated file still "parses" but deploys to a blank page or a worker
  that does nothing. The self-test catches that in seconds — never skip it.

**If the self-test flags a file as incomplete or null-padded, don't debug the
contents — it's the sync hazard, not a code bug.** The copy the shell (and `git`)
sees can be truncated or null-padded even when your file editor shows it intact.
Rebuild the flagged file cleanly (write it via the shell — a heredoc or `printf` —
or into a fresh folder from your correct copy), re-run the self-test, and push only
when green. Two habits that avoid it: write scaffold files via the shell where you
can (the shell's copy is what deploys), and **don't edit `dashboard.html`** — it
arrives already tailored; normally only `worker.js` and `wrangler.toml` change.

---

## Starting level (chosen at the intake — don't re-ask)

The owner already picked how to feed the board: live (connect the owner’s tools; the fallback ladder covers any tool that will not connect).

**The owner chose: live connections.** Run the milestones exactly as written.
If a tool resists (gated API, wrong plan), the fallback ladder is the plan,
not a failure — and a lower rung (upload, or typing one number in weekly) is
a valid place for any single metric to sit while the rest run live.

The ladder (live API → the tool's own export, uploaded or emailed → typed in)
is a menu, not a consolation: the right rung for any number is the
lowest-effort one that reliably gets it on the board, and climbing is always
available later. A board the owner actually reviews every Monday beats a
fully-automated one that never got finished.

---

## The roadmap (show the owner this before starting)

Say something like:

> "Here's the plan. Six steps, and I do nearly all of the work. 1. We get
> set up. 2. I help you make two free accounts: GitHub keeps your dashboard's
> code, and Cloudflare runs it on the internet. 3. I put your dashboard's code
> on GitHub, you connect it in Cloudflare with a few guided clicks, and your
> dashboard comes online. You choose its password on its first screen. 4. We
> connect Xero, and your real money numbers appear. 5. We connect
> Revel Systems, which adds your transaction count and average customer spend. 6. We
> finish up and make it yours. Your part is making two accounts, a few clicks
> in Cloudflare, clicking Allow when a tool asks, choosing a password, and
> checking the numbers look right. You won't touch any code."

---

## Milestone 1: Prep

1. Confirm what the owner needs handy: their **owner/admin logins** for
   Xero and Revel Systems (and rostering: Deputy (rostering, optional: projected wages)), plus an
   email address they control. If they only have a staff-level login, pause
   here and have them get the admin one; connections need it.
2. Set expectations: most steps are yours; theirs take a minute each. The
   whole build is typically a single sitting, but it can stop and resume at
   any milestone.
3. Reassure once, plainly: every connection is **read-only**. The dashboard
   can look at the numbers; it can never change anything in the till or the
   books.

**Owner sees at the end:** nothing yet; they know the plan and have logins
ready.

---

## Milestone 2: Foundations (two free accounts)

The dashboard needs **two** free accounts, both free for what we need: **GitHub**
(where the dashboard's code is kept, so it can be deployed) and **Cloudflare**
(which runs it on the internet and provisions its storage). Create both from
scratch; assume the owner has never heard of either. Use the **Foundations
walk-through (Appendix E)** for the exact, owner-facing steps: one action per
message, what they should see, waiting for them to confirm. You cannot see their
screen, so if it does not match, have them read it out and guide from there.

1. **GitHub.** The owner creates the account, completes the now-mandatory
   two-factor step, and **creates one empty repository in the web UI** — you make
   it *with* them, not for them, because agent sandboxes frequently can't reach
   `api.github.com` or install the GitHub CLI. To push, have the owner generate a
   **fine-grained token** scoped to that repo and paste it to you; git-over-HTTPS
   to `github.com` works even when the API host is blocked. (If your sandbox does
   have the GitHub CLI / device flow, that's a fine shortcut — treat it as
   optional, not the plan.) The owner never sees a git command.
2. **Cloudflare.** The owner creates the account and verifies their email; steer
   them past every paid / add-a-domain prompt. You do **not** need a Cloudflare
   API token: the deploy is done by connecting the repo in the Cloudflare
   dashboard (Milestone 3), which the owner clicks through.
3. Tell the owner plainly: "These two accounts are free and yours. GitHub keeps
   your dashboard's code; Cloudflare runs it. Once we're set up you'll rarely
   open either."

**Owner sees at the end:** two free accounts, an empty repo of their own, and me
able to push your code to it. No code, no jargon.

---

## Milestone 3: Put it online (a real URL, early)

The deploy runs **server-side on Cloudflare** from the code on GitHub: you push,
the owner connects the repo in their Cloudflare dashboard, Cloudflare builds it.
You never run a deploy command against their Cloudflare (you can't reach it), and
nobody pastes code into an editor.

1. **Push the scaffold to the owner's repo.** Put the tailored `scaffold/`
   (frontend + Worker shell; the provider adapters are stubs you'll fill in
   Milestones 4–6) into the empty repo the owner made in Milestone 2, using the
   token they pasted. **First set `name` in `wrangler.toml` to the GitHub repo
   name** — Workers Builds expects them to match (a mismatch makes it open a
   reconciling PR), and it becomes the dashboard's URL. Then **run
   `node selftest.mjs` and push only when it is green** (it catches a truncated
   file before it ever reaches the owner). **Public by default** (the code holds
   no secrets or data); private works too.
2. **Owner connects the repo — Workers Builds (the default).** Walk them, in
   their Cloudflare dashboard: **Workers & Pages → Create → Import a repository →**
   pick their repo → Create/Deploy. This builds **from the repo you just pushed**
   (no clone, no second repo) and **auto-provisions the `TOKENS` storage** from
   `wrangler.toml`. **Appendix F** is the exact click-path. **Pin the storage:**
   once the build succeeds, have the owner read the TOKENS namespace ID from
   Cloudflare (Storage & Databases → KV) and set it as `id` in `wrangler.toml`,
   then push — otherwise a later deploy can re-provision a fresh namespace and
   orphan the saved password and connection tokens. From here, every change you
   push redeploys automatically.
3. **Open the URL — the owner sets their password on the first screen.** Give them
   their dashboard address. The very first screen asks them to choose a dashboard
   password; it's saved **hashed in the dashboard's own storage** — no Cloudflare
   Variables step. (The session-signing key generates itself; never set it.)
   Provider credentials later do use **Settings → Variables and Secrets**, but the
   password does not.
4. **Look around.** Once they're in, every card shows **"Not configured"** — tell
   them that's exactly right here; cards light up as each tool connects.

**One-click alternative — the "Deploy to Cloudflare" button.** Faster for the
owner (it even prompts for the password in its wizard), with one catch worth
knowing: the button **clones your repo into a new repo** in the owner's account
and builds from the clone — so a push token scoped to the original repo can't
push the adapter work Cloudflare actually builds, and you'd be re-scoping the
token mid-build. If you use it, scope the token to **all** the owner's repos (or
create it *after* the button, against the clone). Given that surprise, prefer the
Import path above unless the owner specifically wants one click.

**Owner sees at the end:** their own dashboard URL, live, asking for the password
they chose, honest about being empty.

---

## Milestone 4: Connect Xero (the early win)

This is the connection that matters most: it feeds every money figure
(Revenue, Cost of goods, Wage %, Overheads), and it is the source of truth
the dashboard reconciles against.

1. Run the **per-source connection pattern** (below) for Xero,
   using Appendix A for the credential walk-through.
2. Wire the adapter to pull, per `kpi-spec.md`: the Revenue/Income section,
   the Cost of Sales accounts, the wages + super accounts, and Operating
   Expenses. Everything **ex-GST**, for the venue's timezone, week start,
   and trading-day rollover (set these now; confirm the week start day with
   the owner, it's a business question).
3. Compute and display: Revenue, Cost of goods (+ COGS %), Wage %,
   Overheads, across all periods, with comparison and trend.
4. **Reconcile to the cent** (see the reconciliation section). Do not move
   on until the money figures match the owner's own P&L exactly.

**Owner sees at the end:** real, verified money numbers on their own
dashboard. Make a moment of it; this is the win.

---

## Milestone 5: Connect Revel Systems

1. Run the per-source connection pattern for Revel Systems, using Appendix B.
2. Wire the adapter to pull **one thing only: the count of completed
   transactions** (voids and refunds excluded), per `kpi-spec.md`. Never
   pull a dollar figure from the POS; every money number already comes from
   Xero.
3. Number of transactions goes live, which unlocks **Average customer
   spend** (accounting revenue ÷ POS count, same period).
4. **Reconcile the count** against what the owner sees in Revel Systems for the
   same period.

**Owner sees at the end:** the full core board lit up.

---

## Milestone 6: Rostering, settings, and finishing

1. **Rostering (Deputy (rostering, optional: projected wages)).** If a rostering tool was chosen, run
   the connection pattern (Appendix C) and wire the optional **projected
   Wage %** (rostered cost ÷ revenue), clearly labelled *projected* beside
   the actual. If none, skip; actual Wage % from Xero already
   covers it.
2. **Settings.** Set the owner's preferences with them, in the dashboard's
   settings screen: default period, week start day, venue name, accent
   colour, and their **targets** (each card flags amber when that number
   needs attention).
3. **Handover.** Confirm the unverified banner is gone (every connected
   metric reconciled). Then hand over in plain words: their URL, that data
   refreshes when they open or refresh the dashboard, where settings live, and
   that the small "how did it go?" link is there if they ever want to pass
   feedback along. Remind them: the two accounts, the connected logins, and the
   dashboard password are theirs; don't share the keys or the password with
   anyone.

**Owner sees at the end:** a finished dashboard that is verifiably right,
and everything they need to live with it.

---

## The per-source connection pattern (run this for every tool)

**Step 0: Triage.** Look the tool up in `capability-matrix.md`, then verify
against its current docs: does it have a usable API on the owner's plan?
Which exact product variant is it (confirm with the owner in business terms,
e.g. "is it Lightspeed for restaurants or for shops?")? OAuth or API key?
What are the minimum **read-only** scopes? If there's no usable path, go to
the fallback ladder; never tell the owner it can't be done.

**Path A: live API (preferred):**
1. Walk the owner to the tool's developer/connection screen (appendix or
   current docs), one action per message, each with what they should see.
2. Where the tool asks for a **redirect/callback URL**, the scaffold shows
   the exact URL to use; give it to the owner to paste, or set it yourself
   if you're driving the screen.
3. The owner clicks **Allow/Authorise**. The credential is a **secret** that goes
   into their Cloudflare (you can't reach it yourself to set it). Two ways, in
   order:
   - **If you have Claude-in-Chrome:** use it to open the owner's Cloudflare to
     **Workers & Pages → their dashboard → Settings → Variables and Secrets** and
     position them on the Add form. That dashboard can **stall under automation**,
     so let the **owner click Add and Save** themselves — the browser tool gets
     them to the right place, the owner does the final click.
   - **Otherwise, or if it stalls:** guide them click-by-click through the same
     path. This always works.
   Either way the owner pastes the value and saves, and Cloudflare applies it to
   the running dashboard. Never into the repo, never echoed in chat. After you push
   the wired adapter (`configured: true`), confirm Cloudflare's **latest deployment
   is your newest commit** — a stale build makes a correctly-wired connection look
   broken (the Connect button won't appear).
4. **Confirm the account:** show the owner which account/organisation
   connected and have them confirm it's their business (not a personal
   login, not the bookkeeper's other client, not the wrong venue).
5. **Sandbox check:** if anything suggests a test/demo environment (test
   data, sandbox in the name, round numbers), flag it and steer to the live
   one.
6. Pull a first sync, then reconcile.

If authorisation fails with a redirect/callback mismatch, that means the URL
in the tool's settings doesn't exactly match the scaffold's; fix the URL and
retry. Translate for the owner: "the address didn't match; I've fixed it,
let's try again."

**Path B: automated export (no usable API):** set up the tool's own
scheduled export (email or file drop on a schedule), and stand up the
scaffold's scheduled ingest Worker to read it automatically. Tell the owner
plainly what arrives when, and that the dashboard updates on that rhythm
rather than live.

**Path C: guided upload (last resort):** a simple recurring routine the
owner can do in under a minute (download a report, drop it on the
dashboard's upload screen), with a reminder cadence agreed with the owner.

**Always finish with reconciliation.** No source is "connected" until its
numbers are confirmed.

### Using Claude-in-Chrome (optional accelerator)

If this build has Claude-in-Chrome, it can drive or co-pilot the **unfamiliar
browser screens** for the owner — chiefly the **provider portals** where apps and
tokens are created (the accounting developer site, the POS, the rostering tool),
and getting them to the **Cloudflare Variables-and-Secrets** page. It saves the
owner hunting through developer UIs they have never seen.

Two rules:
- **Never depend on it.** Every step here also has a plain click-by-click guide
  (the Appendices and the per-source pattern). If Claude-in-Chrome is not present,
  or a screen misbehaves, fall straight back to guiding the owner — don't stall
  the build waiting on the browser.
- **The Cloudflare dashboard is the one screen to be careful with:** it can hang
  under automation. Use the browser tool to *navigate* there, then let the
  **owner do the final Add/Save click**. (Going live is Milestone 3's guided
  Import — Appendix F; this note is only for adding provider secrets later.)

---

## Reconciliation (run after every connection)

Money figures come straight from Xero, so they must match the
owner's own P&L **to the cent** for the same dates. The transaction count
must match Revel Systems for the same period. "Close" is not a pass; any gap is a
build bug, and it's yours to find.

Have the owner open their own source of truth and compare. Say something
like: "Open Xero and run your profit and loss for [exact dates].
Does Revenue there say [figure], to the cent?"

**When a figure doesn't match, work this list in order:**
1. **Wrong accounts mapped**: a revenue, Cost of Sales, or wages/super
   account included that shouldn't be, or one missed. Compare account by
   account.
2. **Wrong dates or boundaries**: date range, timezone, week start, or
   trading-day rollover differs from the report the owner ran.
3. **Report basis**: the owner's P&L may be set to cash while the pull is
   accrual (or the reverse). Match the basis of the report they actually
   look at.
4. **GST left in (or taken out twice)**: confirm every pulled figure is
   ex-GST and nothing is being net-ed a second time.
5. **Missing or extra channel**: an income stream (delivery platforms,
   vouchers) sitting in an account the mapping missed, or Other Income
   bleeding into Revenue (it must not; trading income only).

Fix, re-sync, re-check, and only then mark the metric confirmed. If the
owner flags a number as odd later, return to this list.

---

## The fallback ladder (never dead-end)

When a tool has no usable API: **Path B** (its own scheduled export,
auto-ingested) → **pull the same number from another connected tool** (e.g.
labour from Xero's wage accounts instead of the rostering app;
that path already exists for Wage %) → **Path C** (guided upload). There is
always a next rung. The dashboard stays honest about freshness either way.

---

## If you get stuck

1. Name the blocker precisely to yourself: which step, which tool, what
   exactly failed.
2. Walk the fallback ladder before declaring anything blocked.
3. Re-check the tool's current docs; this kit may be older than their
   connection flow.
4. If still blocked, give the owner a short plain-English summary: where
   things stand, what you tried, and the single action that would unblock
   it (theirs or "try again tomorrow"). Keep the rest of the build moving
   in the meantime. Never route the owner to Foodie Coaches.

---

## Appendices: credential walk-throughs

Owner-facing voice in every walk-through: one action per message, what they
should see, no jargon.

### Appendix A: Xero
**Tool: Xero. Path: live API (OAuth). Verified June 2026 — re-check current
docs before starting.**

What you are setting up: the owner's own free Xero app, connected to their
own organisation, with read-only access to exactly one report — the profit
and loss. You do the technical parts; the owner logs in, copies two codes,
and clicks Allow.

**Know before you start (you, not the owner):**

- New Xero apps use **granular scopes**. Request exactly
  `offline_access accounting.reports.profitandloss.read` — the broad
  `accounting.reports.read` no longer exists for new apps.
- Xero's **token endpoint expects HTTP Basic client auth** (`client_secret_basic`):
  the client id and secret go in an `Authorization: Basic` header, not the form
  body. Set the accounting adapter's `tokenAuth: 'basic'` (the scaffold honours it
  in both the code exchange and the refresh). Sending the secret in the body fails
  the exchange *after* the owner clicks Allow — a wasted re-auth. See
  `capability-matrix.md` (Xero) for the full dated specifics and the P&L shape.
- Xero refresh tokens are **single-use and rotate on every refresh**; the
  scaffold's token store handles this — never cache a refresh token outside
  it.
- The free Starter tier (5 connections, 1,000 calls/day) is plenty. Do not
  touch the Journals endpoint; it is premium-gated and not needed.
- You need the scaffold's exact callback URL (the Connections screen shows
  it) before creating the app.

**Walk the owner through, one action per message:**

1. "Open xero.com and make sure you can log in as the owner or admin of your
   business." *They should see their organisation's dashboard.* (A staff or
   adviser login may not be able to approve the connection — pause and get
   the owner login if needed.)
2. "Now open developer.xero.com and sign in with that same Xero login."
   *They should see Xero's developer home with a My Apps option.*
3. "Click My Apps, then New app." *A short form appears.*
4. Tell them exactly what to type, one field per message: an app name (their
   venue name plus the word dashboard is perfect), Web app as the kind, their
   dashboard address for the company URL, and — most important — the exact
   redirect URL you give them, pasted character for character. *Mistyping
   this address is the single most common failure; it must match exactly.*
5. "Tick the developer terms and click Create app." *They land on the app's
   detail page.*
6. **Two values — capture each carefully.** "Open the Configuration section. The
   **Client id** is a long code of letters and numbers — *not* a web address; if
   what you copied starts with `https://`, that's the wrong field (that's the
   app/company URL). Copy the Client id and paste it to me." Then, as a separate
   step: "Now click **Generate a secret** and copy it straight away — it is shown
   **once** and can't be retrieved later. Paste it to me." Keep the two distinct
   (id vs secret). You add both into the owner's Cloudflare in the next step
   (Settings → Variables and Secrets); never echo them back in chat.
7. Build the authorise link with the two scopes above and send it: "Click
   this link, log in if asked, choose your business from the list, and click
   Allow." *They should see Xero asking permission for profit-and-loss
   report access, then a 'connected' confirmation on their dashboard's
   Connections screen.*
8. **Confirm the organisation.** Read the connected organisation name from
   the connection and ask: "It says it connected to [name] — is that your
   business?" If the name contains **Demo Company**, that is Xero's practice
   organisation full of fake data — disconnect and reconnect choosing the
   real one.
9. Run the first sync, then go straight to reconciliation: "Open Xero and
   run your Profit and Loss for [exact dates]. Does Revenue there say
   [figure], to the cent?"

**If it goes wrong:**

- *"Invalid redirect URI" or an error page after clicking Allow* — the
  redirect URL in the app's configuration doesn't exactly match the
  scaffold's. Fix the URL in the app settings, retry. Tell the owner: "the
  address didn't match; I've fixed it, let's try again."
- *insufficient_scope / 401 on the P&L call* — the authorise link is missing
  the granular report scope; rebuild the link with the exact scopes above
  and have them Allow again.
- *Wrong organisation picked* — disconnect, send the authorise link again,
  have them choose the right business.
- *Secret lost before pasting* — generate a new secret in Configuration; the
  old one stops working, which is fine.


### Appendix B: Revel Systems
This tool is not one of the kit’s pre-verified walk-throughs. Run **Appendix D** for Revel Systems: confirm the exact product and plan, find its current developer/integrations documentation, and apply the per-source connection pattern. Its triage entry is in `capability-matrix.md`.

### Appendix C: rostering (Deputy (rostering, optional: projected wages))
**Tool: Deputy. Path: live API (permanent token). Verified June 2026 —
re-check current docs before starting.**

What you are setting up: a **permanent token** from inside the owner's own
Deputy account, so the dashboard can read rosters and compute the projected
Wage % (always labelled *projected* — the actual Wage % already comes from
the accounting software). If this connection stalls, nothing on the core
board is lost; never let Deputy block the build.

**Know before you start (you, not the owner):**

- The permanent token comes from the install's OAuth-clients screen:
  `https://{install}.{geo}.deputy.com/exec/devapp/oauth_clients`. You build
  this exact URL from the owner's Deputy web address (the address they see
  when logged in — e.g. `myvenue.au.deputy.com`).
- A client entry must exist before a token can be issued; the screen has a
  button to add one.
- **The token is shown once, in a pop-up, and never again.** Prepare the
  owner for that before they click.
- The token carries the permission level of the user who creates it — it
  must be created while logged in as the owner/admin.
- How rostered **cost** is exposed (cost fields on the roster vs hours ×
  pay rates) varies; verify the current resource shape in Deputy's developer
  docs when wiring the adapter.

**Walk the owner through, one action per message:**

1. "Log in to Deputy in your browser as the account owner, and tell me the
   web address you see — something like yourvenue.au.deputy.com." *You now
   have the install address.*
2. Send them the exact OAuth-clients URL you built from it: "Open this
   link." *A page about API access / OAuth clients appears.*
3. "Click the button to add a new client, name it [venue] dashboard, and
   save. For any address field it insists on, paste this:" (give the
   scaffold's callback URL — it satisfies the form; the permanent-token path
   won't actually use it). *The client now appears in the list.*
4. "Now the important one: click **Get an Access Token**. A pop-up will show
   a long code **once only**. Copy it straight away and paste it to me
   before closing anything." Store it as a Worker secret immediately; never
   echo it back. *If the pop-up closed too soon, no harm — click the button
   and copy the fresh one.*
5. **Confirm the account.** Read the business name back from the API and
   ask: "It says I'm connected to [business name] — is that your venue?"
6. Run the first sync and sanity-check together: "Open your roster in Deputy
   for [period]. The dashboard's projected wages say [figure] — does that
   look like what your roster screen shows?" (Projected figures reconcile
   approximately against the roster — the to-the-cent rule applies to the
   money figures from the accounting software, and the *actual* Wage % is
   already verified there.)

**If it goes wrong:**

- *The OAuth-clients page won't open* — the install address is wrong
  (re-check what they see when logged in), or their login lacks permission —
  it must be the owner/admin.
- *Token rejected (401)* — copied short, or created under a low-permission
  user; generate a fresh one as the owner.
- *Cost figures look wrong or missing* — fall back a rung without fuss:
  compute from rostered hours × pay rates if exposed, or skip projected
  Wage % (the card shows "not configured") and move on. The build never
  stalls here.


### Appendix D: generic walk-through (any other tool)
1. Confirm the exact product and plan with the owner in business terms.
2. Find the tool's current developer/integrations documentation and locate:
   where connections/apps are created, the auth type, and the minimum
   read-only scopes.
3. Walk the owner to that screen one action at a time, with what they
   should see at each step.
4. Apply the connection pattern from this playbook: redirect URL from the
   scaffold, authorise, secrets to Worker secrets, confirm the account,
   sandbox check, first sync, reconcile.
5. If the tool offers no usable path, take the fallback ladder.

### Appendix E: Foundations walk-through (GitHub and Cloudflare)

These two accounts are the most unfamiliar part for the owner, so go slowly: one
action per message, always say what they should see, and wait for them to confirm
before the next step. You cannot see their screen, so if what they see does not
match what you described, ask them to read out what is on screen and guide from
there.

Plain framing first: "We'll make two free accounts. GitHub is a safe place that
keeps your dashboard's code. Cloudflare puts the dashboard on the internet and
keeps it running. Both are free for what we need and both are yours, and once
they're set up you'll rarely open either."

**GitHub first, so I have somewhere to put your code:**
1. **Create the account.** "Go to https://github.com/signup, enter your email,
   make up a password, and pick a username. Tell me when you're in."
2. **Verify and two-factor.** "GitHub emails you a code to confirm, then asks you
   to set up two-factor — a normal security step now. Pick the text-message or
   app option and follow it. Tell me when you reach your new, empty GitHub home."
3. **Create one empty repository (in the web UI).** "Click the + at the top right
   → New repository, give it a name (your venue plus 'dashboard' is fine), leave
   it empty, and Create. Then copy the repository's web address and paste it to
   me." The owner makes the repo because agent sandboxes frequently **can't reach
   `api.github.com`, install the GitHub CLI (`cli.github.com`), or use the device
   flow** — only `github.com` itself is reliably reachable, and git-over-HTTPS to
   it still works for pushing.
4. **A token so I can push.** "Open your profile photo → Settings → Developer
   settings → Fine-grained tokens → Generate new token. Under Repository access
   pick that one repo; under Permissions set Contents to Read and write. Generate
   it, copy it, and paste it to me." Treat it as a secret — store it, never echo
   it. You now push over `github.com`; the owner never sees a git command. (If
   your sandbox happens to have the GitHub CLI or device flow you may use that
   instead — but this token-plus-web-UI path is the one that works everywhere.)

**Cloudflare:**
1. **Create the account.** "Go to https://dash.cloudflare.com/sign-up, enter your
   email, make up a password, and click Sign up. Tell me when that's done." (If
   they already have one, they just sign in.)
2. **Verify the email.** "Cloudflare emails a confirm link. Open it and you'll
   land back on Cloudflare; check spam if it's not there in a minute. Tell me
   when you're in."
3. **Skip the extras.** If it asks them to add a website or pick a plan, the free
   option is all we need: no domain, nothing paid. Steer them past it; if a
   screen looks different, have them read it out.
4. **No token needed.** The deploy connects the repo in the Cloudflare dashboard
   (Milestone 3; **Appendix F** is the exact click-path) — you don't need a
   Cloudflare API token for it.
5. **Confirm.** "Both accounts are ready: GitHub holds your code, Cloudflare will
   run it." Continue to Milestone 3 (put it online; the owner sets a password on
   the dashboard's first screen).

### Appendix F: Cloudflare deploy walk-through (Workers Builds → Import a repository)

This is the deploy in Milestone 3. The screens are unfamiliar to the owner, so
drive or co-pilot them: if you have Claude-in-Chrome, open and navigate these
screens yourself rather than asking the owner to read them out — the owner does
the final clicks (the Cloudflare dashboard can stall under full automation, so
position, then let them click). One action per message; say what they should see.
Verified June 2026 — re-check the current labels before starting.

1. "In Cloudflare, open **Workers & Pages** (left menu), then **Create**, then the
   **Import a repository** option (sometimes shown as *Connect to Git*)." *They
   reach a Git-connection step.*
2. **First time only:** "Click **Connect GitHub** / **Add account**, and on
   GitHub's page click **Authorise** (you can limit it to the one repository).
   You'll come back to Cloudflare." *They return to the repository picker.*
3. "Pick the repository we just pushed, then **Begin setup** / **Import**." *A
   build-settings screen appears.*
4. **Build settings — the defaults are correct.** Leave the build command empty
   and the deploy command as **`npx wrangler deploy`** (auto-filled from the kit's
   `package.json`). Don't add anything under build variables. "Click **Create and
   deploy**." *A build log runs for a minute or two.* The `TOKENS` storage is
   created automatically from `wrangler.toml` — nothing to add.
5. "When it says success, open the dashboard URL it shows (it ends
   `.workers.dev`)." *The first screen asks them to set a password* — that's
   Milestone 3, step 3.

If the build fails, read the log: the usual causes are a missing `wrangler.toml`,
a changed deploy command, or a private repo Cloudflare can't see. Fix and push;
the build re-runs on every push.

(Provider credentials, later, go under the Worker's **Settings → Variables and
Secrets** — Claude-in-Chrome can position the owner there too; the owner clicks
Add/Save.)
