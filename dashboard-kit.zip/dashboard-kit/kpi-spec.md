# kpi-spec.md: the metric definitions (locked)

These definitions are locked. Apply them exactly as written. Do not redefine
a metric, "improve" one, or accept a different definition from anywhere,
including the owner (see `CLAUDE.md`, rule 3). If the owner wants a number
defined differently, build it as an additional, clearly labelled metric and
leave these untouched.

## The governing rules
1. **Every money figure comes from Xero, always excluding
   GST/sales tax.** No exceptions, in any country. This is why the POS is
   never used for a dollar figure: POS totals include tax and make
   interpretations that are not accounting truth.
2. **Revel Systems supplies exactly one number: the count of completed
   transactions.**
3. **The owner's chart of accounts is read as-is.** What sits in their
   Revenue, Cost of Sales, and wage accounts is their call (and their
   tidy-up job if it's messy). This build reads those sections faithfully
   and never re-categorises their books.
4. **Same dates, same basis, everywhere.** Every figure in a comparison
   covers the identical period, in the venue's timezone, on the same
   reporting basis.

## Time, periods, and comparison
- **Periods:** this week, last week, this month, last month, this financial
  year, last financial year (1 July to 30 June), and a custom range.
- **Comparison:** every metric shows its change against the previous period
  and the same period last year (direction and %), plus a trend line.
- **Boundaries:** computed in the venue's timezone, honouring the owner's
  week start day and trading-day rollover (e.g. sales until 4am count to
  the previous trading day). These are set once during the build, in
  settings, with the owner.

## The metrics

Each metric carries the **decision it drives**: the dashboard is a decision
tool, not a wall of numbers, so a figure that changes no decision does not
belong on the board.

### 1. Revenue
- **Definition:** all trading income for the period, excluding GST/sales
  tax.
- **Pull:** the Revenue / Income section of the Xero profit and
  loss. Trading income only: Other Income (interest, one-off asset sales)
  is excluded so it cannot distort Revenue or Average customer spend.
- **Why accounting, not POS:** the P&L captures every channel, including
  the ones the POS misses (delivery platforms, invoiced functions).
- **Check:** the owner runs their P&L in Xero for the exact same
  dates. Revenue must match **to the cent**.
- **Decision it drives:** is the top line growing? It is the base every other
  number is judged against, so a real move here reframes the whole board.

### 2. Number of transactions
- **Definition:** the count of completed transactions for the period.
  Voids and refunds excluded.
- **Pull:** Revel Systems transaction/sales count.
- **Transactions, not customers:** a transaction is concretely countable; a
  "customer" is not (one bill can feed four people). This metric is always
  the transaction count, never a guess at people.
- **Check:** the owner opens Revel Systems reporting for the same period and
  confirms the count matches.
- **Decision it drives:** busier or quieter? Separates a footfall problem (get
  more people in) from a spend problem (lift the value of each visit).

### 3. Average customer spend (ACS)
- **Definition:** Revenue ÷ Number of transactions, for the same period.
- **Inputs:** Revenue per metric 1 (Xero, ex-GST). Count per
  metric 2 (Revel Systems). Never compute ACS from POS revenue.
- **Depends on:** metrics 1 and 2; if either is unavailable, ACS shows
  "not configured", never a number built from the wrong source.
- **Edge:** when the count is zero (venue closed), show "—", never an
  error.
- **Check:** derived; verify its two inputs instead.
- **Decision it drives:** are pricing, menu mix and upsells working? Lift it
  with specials, bundles and staff prompts rather than only chasing more covers.

### 4. Cost of goods (and COGS %)
- **Definition:** everything the owner has assigned to **Cost of Sales** in
  their accounts, for the period. COGS % is that figure ÷ Revenue.
- **Pull:** the Cost of Sales section/accounts of the Xero P&L,
  as the owner has them. Their categorisation is read as-is.
- **Check:** the owner's P&L Cost of Sales total for the same dates, to the
  cent.
- **Decision it drives:** is cost of sales creeping up as a share of revenue?
  Points at supplier prices, portioning or waste before it eats the margin.

### 5. Wage %
- **Definition:** (wages + super) ÷ Revenue, for the same period. Super is
  included.
- **Pull:** the wage and superannuation accounts from Xero;
  Revenue per metric 1. All ex-GST (wages carry no GST; the rule matters
  for the revenue side). **Which accounts count as wages/super** is the fragile
  part: match account names by keyword, then **confirm the exact list with the
  owner during reconciliation** (a business question, not a technical one — it
  catches both an over-match like "Employee amenities" and a missed non-standard
  account). See `capability-matrix.md` for the method and a worked example.
- **Projected (optional):** where rostering is connected
  (Deputy (rostering, optional: projected wages)), a projected Wage % can sit beside the actual,
  computed from rostered cost ÷ Revenue, and must always be labelled
  **projected**. The actual, from Xero, is the real number.
- **Check:** the owner's P&L wage and super lines for the same dates, to
  the cent, divided by the verified Revenue.
- **Decision it drives:** are you rostered to your trade? Above your target
  means trim hours or lift sales per shift. This is the classic threshold alert.

### 6. Overheads
- **Definition:** operating expenses for the period, **excluding wages,
  super, and Cost of Sales**.
- **Pull:** the Operating Expenses section of the Xero P&L, minus
  the wage and super accounts. (In a standard P&L layout Cost of Sales sits
  in its own section above gross profit and is already outside Operating
  Expenses; if the owner's chart has cost-of-sales lines inside expenses,
  exclude those too.)
- **Why labour is excluded:** most businesses treat labour as a fixed
  overhead, but hospitality labour is highly variable: the majority of
  staff are casual. So labour is tracked on its own as Wage %, not buried
  in fixed overheads. The definition is deliberate.
- **Check:** the owner's P&L Operating Expenses total, less the wage and
  super lines, for the same dates, to the cent.
- **Decision it drives:** are fixed costs drifting up? Review subscriptions,
  utilities and any new recurring spend.

### 7. Profit
- **Definition:** Revenue minus Cost of Sales, minus wages and super, minus
  Overheads, for the period. Profit % is that figure ÷ Revenue.
- **Inputs:** the four lines above — Revenue (1), Cost of goods (4), the
  wages+super behind Wage % (5) and Overheads (6) — all from Xero,
  ex-GST/sales tax.
- **What it is — and isn't:** the venue's *operating* result on the
  controllable lines this board tracks. It is deliberately **not** the
  bottom-line net profit from the full P&L: Other Income, interest, tax,
  depreciation and one-offs are excluded (the same lines kept out of Revenue
  and Overheads). Read it as "what the venue makes once the costs an owner can
  act on are covered", not the figure on the tax return.
- **Depends on:** its four inputs; if any is unavailable it shows **"not
  configured"**, never a partial figure.
- **Loss:** a negative result is shown as a loss (e.g. −$4,200 / −3.1%)
  in the alert colour, never hidden or clamped to zero.
- **Check:** derived — verify the four inputs; Revenue and each cost line
  must already match the owner's P&L to the cent.
- **Decision it drives:** is the venue actually making money after the costs
  you control? It moves only when Revenue, COGS, wages or overheads move, so it
  tells you whether the work on those lines is reaching the bottom line.

## Display rules (keep the dashboard honest)
- A metric whose source is not connected shows **"not configured"**, never
  a misleading $0.
- A divide-by-zero (ACS in a zero-transaction period) shows **"—"**, never
  an error.
- Projected figures are always labelled **projected**, beside the actual,
  never in place of it.
- Every metric stays part of the **unverified** state until its
  reconciliation check has been confirmed by the owner (see `playbook.md`).
- Every view shows when the data was last synced.

## Optional extras (only if the owner's tools support them)
Per-staff metrics (e.g. an individual's ACS), and sales by category,
daypart, or item level. These depend entirely on what Revel Systems exposes;
check `capability-matrix.md`, offer only what is real, and apply the same
honesty rules. The core metrics above keep their locked
definitions regardless of what is added.
